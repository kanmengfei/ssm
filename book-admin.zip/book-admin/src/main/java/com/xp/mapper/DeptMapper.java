package com.xp.mapper;

import com.xp.pojo.Dept;
import com.xp.pojo.User;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;


/**
 * (Demp)表数据库访问层
 *
 * @author makejava
 * @since 2021-07-14 09:40:34
 */
public interface DeptMapper {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    Dept queryById(Integer id);

    /**
     * 查询指定行数据
     *
     * @param offset 查询起始位置
     * @param limit  查询条数
     * @return 对象列表
     */
    List<Dept> queryAllByLimit(@Param("offset") int offset, @Param("limit") int limit
                                ,@Param("deptId") Integer deptId);


    /**
     * 通过实体作为筛选条件查询
     *
     * @param demp 实例对象
     * @return 对象列表
     */
    List<Dept> queryAll(Dept demp);

    /**
     * 新增数据
     *
     * @param demp 实例对象
     * @return 影响行数
     */
    int insert(Dept demp);

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<Demp> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<Dept> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<Demp> 实例对象列表
     * @return 影响行数
     */
    int insertOrUpdateBatch(@Param("entities") List<Dept> entities);

    /**
     * 修改数据
     *
     * @param demp 实例对象
     * @return 影响行数
     */
    int update(Dept demp);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 影响行数
     */
    int deleteById(Integer id);

    @Select("select * from dept where name = #{name}")
    List<User> selectByName(String name);
}

