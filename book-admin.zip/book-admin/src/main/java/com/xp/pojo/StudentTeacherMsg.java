package com.xp.pojo;

import java.io.Serializable;

/**
 * (StudentTeacherMsg)实体类
 *
 * @author makejava
 * @since 2021-07-13 13:44:54
 */
public class StudentTeacherMsg implements Serializable {
    private static final long serialVersionUID = 734695136998898171L;

    private Integer id;
    /**
     * 学生id
     */
    private Integer studentId;
    /**
     * 老师id
     */
    private Integer teacherId;
    /**
     * 等级1，2，3
     */
    private Integer type;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public Integer getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(Integer teacherId) {
        this.teacherId = teacherId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}
