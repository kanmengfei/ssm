package com.xp.pojo;

import java.io.Serializable;

/**
 * (User)实体类
 *
 * @author makejava
 * @since 2021-07-14 10:34:31
 */
public class User implements Serializable {
    private static final long serialVersionUID = -76435777068835355L;

    private Integer id;
    /**
     * 管理员名称
     */
    private String name;
    /**
     * 密码
     */
    private String password;
    /**
     * 地址
     */
    private String role;
    /**
     * 电话
     */
    private String phone;
    /**
     * 是否支付 N未支付 Y已支付
     */
    private String pay;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPay() {
        return pay;
    }

    public void setPay(String pay) {
        this.pay = pay;
    }
}
