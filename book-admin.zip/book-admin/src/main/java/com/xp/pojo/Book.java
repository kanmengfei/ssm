package com.xp.pojo;

import java.io.Serializable;

/**
 * (Book)实体类
 *
 * @author makejava
 * @since 2021-07-27 20:49:27
 */
public class Book implements Serializable {
    private static final long serialVersionUID = 206173217783576475L;

    private Integer id;

    private String name;

    private Double price;
    /**
     * 作者
     */
    private String author;
    /**
     * 是否收费 Y是 N否
     */
    private String charge;

    private String image;

    private String file;
    /**
     * 审核 0未审核  1审核不通过  2审核通过
     */
    private Byte audit;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getCharge() {
        return charge;
    }

    public void setCharge(String charge) {
        this.charge = charge;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public Byte getAudit() {
        return audit;
    }

    public void setAudit(Byte audit) {
        this.audit = audit;
    }
}
