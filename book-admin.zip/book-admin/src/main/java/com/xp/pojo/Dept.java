package com.xp.pojo;

import java.io.Serializable;


/**
 * (Demp)实体类
 *
 * @author makejava
 * @since 2021-07-14 09:40:34
 */
public class Dept implements Serializable {
    private static final long serialVersionUID = -99952756065737146L;

    private Integer id;
    /**
     * 部门名称
     */
    private String name;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
