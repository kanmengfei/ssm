package com.xp.pojo;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.io.Serializable;


/**
 * (Staff)实体类
 *
 * @author makejava
 * @since 2021-07-14 09:40:35
 */
public class Staff implements Serializable {
    private static final long serialVersionUID = 428039824344816592L;

    private Integer id;
    /**
     * 姓名
     */
    private String name;
    /**
     * 出生日期
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date date;
    /**
     * 性别
     */
    private String sex;
    /**
     * 岗位
     */
    private String gangWei;
    /**
     * 工资
     */
    private Integer salary;
    /**
     * 补贴
     */
    private Integer subsidy;
    /**
     * 部门编号
     */
    private Integer deptId;

    private String deptName;
    /**
     * 密码
     */
    private String password;

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getGangWei() {
        return gangWei;
    }

    public void setGangWei(String gangWei) {
        this.gangWei = gangWei;
    }

    public Integer getSalary() {
        return salary;
    }

    public void setSalary(Integer salary) {
        this.salary = salary;
    }

    public Integer getSubsidy() {
        return subsidy;
    }

    public void setSubsidy(Integer subsidy) {
        this.subsidy = subsidy;
    }

    public Integer getDeptId() {
        return deptId;
    }

    public void setDeptId(Integer deptId) {
        this.deptId = deptId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
