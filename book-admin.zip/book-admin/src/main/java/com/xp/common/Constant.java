package com.xp.common;

public class Constant {

    public static final String CODE = "CODE";
    public static final String CURRENT_USER = "CURRENT_USER";
    public static final String CURRENT_STAFF = "CURRENT_STAFF";
    public static final String TOKEN = "TOKEN";
}
