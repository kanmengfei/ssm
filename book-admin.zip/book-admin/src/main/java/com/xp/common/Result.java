package com.xp.common;


public class Result {

    private Integer code;
    private String msg;
    private Object data;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }


    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public static Object ok() {
        Result responseCode = new Result();
        responseCode.setCode(0);
        responseCode.setMsg("成功");
        return responseCode;
    }

    public static Object ok(Object date) {
        Result responseCode = new Result();
        responseCode.setCode(0);
        responseCode.setMsg("成功");
        responseCode.setData(date);
        return responseCode;
    }

    public static Object fail() {
        Result responseCode = new Result();
        responseCode.setCode(-1);
        responseCode.setMsg("失败");
        return responseCode;
    }

    public static Object fail(String msg) {
        Result responseCode = new Result();
        responseCode.setCode(-1);
        responseCode.setMsg(msg);
        return responseCode;
    }

}
