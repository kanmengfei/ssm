package com.xp.common;

import com.xp.pojo.Staff;
import com.xp.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;

import javax.servlet.http.HttpSession;

public class  AdminUserSession {

    @Autowired
    private HttpSession session;

    public User getCurrentAdminUser() {
        return (User) session.getAttribute(Constant.CURRENT_USER);
    }
    public void  saveCurrentAdminUser(User adminUser) {
        session.setAttribute(Constant.CURRENT_USER, adminUser);
    }

    public void  removeCurrentAdminUser() {
        session.removeAttribute(Constant.CURRENT_USER);
    }

    public void  saveCurrentAdminStaff(Staff adminUser) {
        session.setAttribute(Constant.CURRENT_STAFF, adminUser);
    }
    public Staff getCurrentAdminStaff() {
       return (Staff) session.getAttribute(Constant.CURRENT_USER);
    }


}
