package com.xp.filter;

import com.xp.common.Constant;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * 预览下载等操作跳转到登录页面
 */
@WebFilter(urlPatterns = {"/book/downloadPdf", "/book/previewPdf","/book/save","/user/pay"})
public class MyFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpSession session = request.getSession();
        Object user = session.getAttribute(Constant.CURRENT_USER);
        if (user == null) {
            //如果没有登录的话，就重定向到登陆页面
            HttpServletResponse response = (HttpServletResponse) servletResponse;
            response.setHeader("redirectUrl","/html/index.html");
            //设置跳转使能
            response.setHeader("enableRedirect","true");
            response.flushBuffer();
        } else {
            filterChain.doFilter(request, servletResponse);
        }
    }

    @Override
    public void destroy() {

    }
}
