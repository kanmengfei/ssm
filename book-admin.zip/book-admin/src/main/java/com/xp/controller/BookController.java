package com.xp.controller;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.IoUtil;
import com.github.pagehelper.PageInfo;
import com.xp.common.R;
import com.xp.pojo.Book;
import com.xp.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;

/**
 * (Book)表控制层
 *
 * @author makejava
 * @since 2021-07-27 20:49:33
 */
@RestController
@RequestMapping("/book")
public class BookController {
    /**
     * 服务对象
     */
    @Resource
    private BookService bookService;
    @Autowired
    private ServletContext servletContext;

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @RequestMapping("/get")
    public Book getById(Integer id) {
        return this.bookService.queryById(id);
    }

    @RequestMapping("/save")
    public Object save(Book book) {
        System.out.println(book);
        return bookService.save(book);
    }

    @RequestMapping("/list")
    public PageInfo<Book> getPage(Integer pageNum, Integer pageSize) {
        if (pageNum == null) {pageNum = 1;}
        if (pageSize == null) {pageSize = 20;}
        return bookService.getPage(pageNum, pageSize);
    }

    @RequestMapping("/update")
    public Object updateById(Book book) {
        bookService.update(book);
        return R.ok();
    }

    @RequestMapping("/delete")
    public Object deleteById(@RequestParam Integer id) {
        return bookService.deleteById(id);
    }
    private static final String BASE_PATH = "D:/book-file";

    /**
     * 上传
     * @param file
     * @return
     */
    @RequestMapping(value = "/uploadFile", method = RequestMethod.POST)
    public Object uploadFile(MultipartFile file) {
        FileUtil.mkdir(BASE_PATH);
        String originalFilename = file.getOriginalFilename();
        String filePath = BASE_PATH + File.separator + originalFilename;
        try (InputStream inputStream = file.getInputStream();
             FileOutputStream out = new FileOutputStream(filePath)) {
            IoUtil.copy(inputStream, out);
            return R.ok();
        } catch (IOException e) {
            e.printStackTrace();
            return R.fail();
        }
    }

    /**
     * 下载
     * @param filename
     * @param response
     * @throws UnsupportedEncodingException
     */
    @RequestMapping(value = "/downloadPdf")
    public void downloadPdf(String filename, HttpServletResponse response) throws UnsupportedEncodingException {
        String filePath = BASE_PATH + File.separator + filename;
        response.setContentType(servletContext.getMimeType(filename));
        String contentFilename = URLEncoder.encode(filename, "UTF-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + contentFilename);
        try (FileInputStream in = new FileInputStream(filePath);
             OutputStream out = response.getOutputStream()) {
            byte[] buf = new byte[1024];
            int len = 0;
            while ((len = in.read(buf)) != -1) {
                out.write(buf, 0, len);
            }
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 预览pdf
     * @param filename
     * @param response
     * @throws UnsupportedEncodingException
     */
    @RequestMapping(value = "/previewPdf")
    public void previewPdf(String filename, HttpServletResponse response) throws UnsupportedEncodingException {
        String filePath = BASE_PATH + File.separator + filename;
        response.setContentType(servletContext.getMimeType(filename));
        String contentFilename = URLEncoder.encode(filename, "UTF-8");
        response.setHeader("Content-Disposition", "inline;filename=" + contentFilename);
        try (FileInputStream in = new FileInputStream(filePath);
             OutputStream out = response.getOutputStream()) {
            byte[] buf = new byte[1024];
            int len = 0;
            while ((len = in.read(buf)) != -1) {
                out.write(buf, 0, len);
            }
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 预览图片
     * @param imagename
     * @param response
     * @throws UnsupportedEncodingException
     */
    @RequestMapping(value = "/previewImage")
    public void previewImage(String imagename, HttpServletResponse response) throws UnsupportedEncodingException {
        String filePath = BASE_PATH + File.separator + imagename;
        response.setContentType(servletContext.getMimeType(imagename));
        String contentFilename = URLEncoder.encode(imagename, "UTF-8");
        response.setHeader("Content-Disposition", "inline;filename=" + contentFilename);
        try (FileInputStream in = new FileInputStream(filePath);
             OutputStream out = response.getOutputStream()) {
            byte[] buf = new byte[1024];
            int len = 0;
            while ((len = in.read(buf)) != -1) {
                out.write(buf, 0, len);
            }
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
