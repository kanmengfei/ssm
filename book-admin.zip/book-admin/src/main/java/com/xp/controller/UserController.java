package com.xp.controller;

import com.xp.common.AdminUserSession;
import com.xp.common.Constant;
import com.xp.common.R;
import com.xp.pojo.User;
import com.xp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private AdminUserSession adminUserSession;
    @Autowired
    private HttpSession session;


    @RequestMapping("/get")
    public Object getById(Integer id) {
        return userService.getById(id);
    }

    @RequestMapping("/delete")
    public Object deleteById(@RequestParam Integer id) {
        return userService.delete(id);
    }
    @RequestMapping("/save")
    public Object save(User user) {
        return userService.save(user);
    }

    @RequestMapping("/update")
    public Object updateById(User user) {
        return userService.save(user);
    }

    @RequestMapping("/login")
    public Object login(User user) {
        return userService.login(user);
    }

    @RequestMapping("/logout")
    public Object logout() {
        adminUserSession.removeCurrentAdminUser();
        return R.ok();
    }

    @RequestMapping("/list")
    public Object getPage(Integer pageNum, Integer pageSize) {
        if (pageNum == null) {pageNum = 1;}
        if (pageSize == null) {pageSize = 20;}
        Object page = userService.getPage(pageNum, pageSize);
        return page;
    }

    /**
     * 支付
     * @return
     */
    @RequestMapping("/pay")
    public Object pay() {
        User currentUser = adminUserSession.getCurrentAdminUser();
        currentUser.setPay("Y");  //将支付状态改为已支付
        return userService.updateById(currentUser);
    }

    @RequestMapping(value = "/update/password", method = RequestMethod.POST)
    public Object updatePassword(String newPass, String oldPass) {
        return userService.updatePassword(newPass, oldPass);
    }

}
