package com.xp.controller;

import com.xp.pojo.Dept;
import com.xp.pojo.User;
import com.xp.service.DeptService;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Map;

/**
 * (Demp)表控制层
 *
 * @author makejava
 * @since 2021-07-14 09:40:34
 */
@RestController
@RequestMapping("/dept")
public class DeptController {
    /**
     * 服务对象
     */
    @Resource
    private DeptService deptService;

    @RequestMapping("/get")
    public Object getById(Integer id) {
        return deptService.queryById(id);
    }

    @RequestMapping("/delete")
    public Object deleteById(@RequestParam Integer id) {
        return deptService.deleteById(id);
    }

    @RequestMapping("/save")
    public Object save(Dept dept) {
        return deptService.insert(dept);
    }

    @RequestMapping("/update")
    public Object updateById(Dept dept) {
        return deptService.update(dept);
    }

    @RequestMapping("/list")
    public Object listInteger(Integer pageNum, Integer pageSize) {
        return deptService.list(pageNum, pageSize);
    }

    @RequestMapping(path = "/staffList")
    public Object staffList(@RequestBody Map<String,Object> map ) {
        return deptService.staffList(0, 12, 2);
    }


}
