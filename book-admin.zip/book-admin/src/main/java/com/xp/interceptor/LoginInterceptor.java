//package com.xp.interceptor;
//
//
//import com.xp.common.Constant;
//import com.xp.pojo.User;
//import org.springframework.web.servlet.HandlerInterceptor;
//import org.springframework.web.servlet.ModelAndView;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//
//public class LoginInterceptor implements HandlerInterceptor{
//
//	public boolean preHandle(HttpServletRequest request,HttpServletResponse response, Object handler) throws Exception {
//
//		try {
//			User user = (User) request.getSession().getAttribute(Constant.CURRENT_USER);
//			if(user != null){
//				return true;
//			}
//			response.setHeader("REDIRECT","REDIRECT");
//			response.setHeader("PATH","/");
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return false;
//	}
//
//	public void postHandle(HttpServletRequest request,
//			HttpServletResponse response, Object handler,
//			ModelAndView modelAndView) throws Exception {
//
//	}
//
//	public void afterCompletion(HttpServletRequest request,
//			HttpServletResponse response, Object handler, Exception ex)
//			throws Exception {
//
//	}
//
//}
